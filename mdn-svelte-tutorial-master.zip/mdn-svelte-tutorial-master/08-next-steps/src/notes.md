https://www.robertcooper.me/using-eslint-and-prettier-in-a-typescript-project

npm i -D eslint @typescript-eslint/parser @typescript-eslint/eslint-plugin

