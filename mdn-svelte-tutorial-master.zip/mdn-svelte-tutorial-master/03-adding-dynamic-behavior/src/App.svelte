<script>
  import Todos from './components/Todos.svelte'
</script>

<Todos />