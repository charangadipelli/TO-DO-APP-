export enum Filter {
  ALL = "all",
  ACTIVE = "active",
  COMPLETED = "completed",
}